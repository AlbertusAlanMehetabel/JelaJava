package com.dicoding.jelajava.Activity.Fragment.ProfileFragment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.jelajava.Data.UseCase.ProfileUseCase
import com.dicoding.jelajava.Misc.Utility.ProfileViewState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class ProfileViewModel(private val profileUseCase: ProfileUseCase) : ViewModel() {
    private val _profileState = MutableStateFlow(ProfileViewState())
    val profileState = _profileState.asStateFlow()

    fun getProfile() {
        viewModelScope.launch {
            profileUseCase().collect {profile->
                _profileState.update {
                    it.copy(profileUser = profile)
                }
            }
        }
    }
    class Factory(
        private val profileUseCase: ProfileUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(ProfileViewModel::class.java)) {
                return ProfileViewModel(profileUseCase) as T
            }
            error("Unknown ViewModel class: $modelClass")
        }
    }
}