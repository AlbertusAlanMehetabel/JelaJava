package com.dicoding.jelajava.Data.Response.authResponse

data class UserResponse(
    val message: String,
    val user: UserData
)
data class UserData(
    val profilePicture: String,
    val name: String,
    val email: String
)

