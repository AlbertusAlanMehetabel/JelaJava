package com.dicoding.jelajava.Data.Response.authResponse

data class UserEntity(
    val accessToken: String
)
