package com.dicoding.jelajava.Activity.SettingActivity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.jelajava.Data.UseCase.LogoutUseCase
import kotlinx.coroutines.launch

class SettingViewModel( private val logoutUseCase: LogoutUseCase): ViewModel() {

    fun logout() {
        viewModelScope.launch {
            logoutUseCase()
        }
    }

    class Factory(private val logoutUseCase: LogoutUseCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(SettingViewModel::class.java)) {
                return SettingViewModel(logoutUseCase) as T
            }
            error("Unknown ViewModel class: $modelClass")
        }
    }
}