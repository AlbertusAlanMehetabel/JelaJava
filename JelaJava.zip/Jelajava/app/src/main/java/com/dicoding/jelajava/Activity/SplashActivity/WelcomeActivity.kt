package com.dicoding.jelajava.Activity.SplashActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.os.Handler
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.dicoding.jelajava.Activity.LoginActivity.LoginActivity
import com.dicoding.jelajava.Activity.MainActivity.MainActivity
import com.dicoding.jelajava.Misc.Utility.Injection
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.launchAndCollectIn
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.ActivityWelcomeBinding

class WelcomeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityWelcomeBinding
    private val viewModel by viewModels<SplashViewModel>(factoryProducer = { Injection.splashViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityWelcomeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        Glide.with(this)
            .load(getString(R.string.logo_url))
            .into(binding.logo)

        viewModel.splashState.launchAndCollectIn(this) {
            if (it.resultIsLoggedIn is ResultState.Success) {
                if (it.resultIsLoggedIn.data == true) {
                    startActivity(
                        Intent(this@WelcomeActivity, MainActivity::class.java).addFlags(
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                        )
                    )
                    finish()
                } else {
                    startActivity(
                        Intent(this@WelcomeActivity, LoginActivity::class.java).addFlags(
                            Intent.FLAG_ACTIVITY_CLEAR_TOP
                        )
                    )
                    finish()
                }
            }
        }
    }
}