package com.dicoding.jelajava.Misc.Utility

import com.dicoding.jelajava.Data.Response.Recommendation.Kota
import com.dicoding.jelajava.Data.Response.authResponse.ProfileEntity

data class WelcomeViewState (
    val resultIsLoggedIn: ResultState<Boolean> = ResultState.Idle()
)

data class LoginViewState(
    val verifyUser: ResultState<String> = ResultState.Idle()
)

data class RegisterViewState(
    val resultRegisterUser: ResultState<String> = ResultState.Idle()
)

data class RecommendViewState(
    val resultRecommend: ResultState<Kota> = ResultState.Idle()
)

data class ProfileViewState(
    val profileUser: ResultState<ProfileEntity> = ResultState.Idle()
)
