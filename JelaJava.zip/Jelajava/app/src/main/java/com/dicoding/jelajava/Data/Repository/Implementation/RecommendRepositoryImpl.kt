package com.dicoding.jelajava.Data.Repository.Implementation

import com.dicoding.jelajava.Data.Api.ApiService
import com.dicoding.jelajava.Data.Repository.RecommendRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class RecommendRepositoryImpl(private val apiService: ApiService): RecommendRepository {

    override fun getRecommend(rec: String) = flow {
        emit(
            apiService.recommend(
                hashMapOf(
                    Pair("city", rec)
                )
            )
        )
    } .flowOn(Dispatchers.IO)
}