package com.dicoding.jelajava.Activity.LoginActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.dicoding.jelajava.Activity.MainActivity.MainActivity
import com.dicoding.jelajava.Activity.RegisterActivity.RegisterActivity
import com.dicoding.jelajava.Misc.Utility.Injection
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.launchAndCollectIn
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.ActivityLoginBinding

class LoginActivity : AppCompatActivity() {
    private lateinit var binding: ActivityLoginBinding
    private val viewModel by viewModels<LoginViewModel>(factoryProducer = {Injection.loginViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        loginStart()

        viewModel.loginState.launchAndCollectIn(this) { state ->
            when(state.verifyUser) {
                is ResultState.Success<String> -> {
                    showLoading(false)
                    showLoading(false)
                    startActivity(Intent(this@LoginActivity,MainActivity::class.java))
                    finish()
                }
                is ResultState.Loading -> showLoading(true)
                is ResultState.Error -> {
                    showLoading(false)
                    Toast.makeText(this@LoginActivity, state.verifyUser.message, Toast.LENGTH_SHORT).show()
                }

                else -> Unit
            }
        }


        binding.btnLogin.setOnClickListener{
            viewModel.login(
                email = binding.edtEmailLogin.text.toString(),
                password = binding.edtPasswordLogin.text.toString(),
            )
        }

        Glide.with(this)
            .load(getString(R.string.logo_url))
            .into(binding.logo)

        binding.txtToRegister.setOnClickListener{
            startActivity(
                Intent(
                    this, RegisterActivity::class.java
                )
            )
        }
        binding.edtPasswordLogin.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                loginStart()
            }
            override fun afterTextChanged(s: Editable) {
            }
        })
    }

    private fun loginStart() {
        val validPassword = binding.edtPasswordLogin.text.toString()
        binding.btnLogin.isEnabled = !TextUtils.isEmpty(validPassword) && validPassword.length >= 8

    }

    private fun showLoading(isLoading: Boolean) {
        binding.PBLogin.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}