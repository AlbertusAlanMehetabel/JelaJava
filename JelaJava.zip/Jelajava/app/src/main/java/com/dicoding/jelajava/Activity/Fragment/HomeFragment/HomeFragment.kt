package com.dicoding.jelajava.Activity.Fragment.HomeFragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.jelajava.Data.Adapter.KotaAdapter
import com.dicoding.jelajava.Misc.Utility.Injection
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.launchAndCollectIn
import com.dicoding.jelajava.databinding.FragmentHomeBinding
class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!
    private val adapter by lazy { KotaAdapter() }

    private val viewModel by viewModels<HomeViewModel>(factoryProducer = { Injection.homeViewModelFactory })

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater,container,false)

        viewModel.homeState.launchAndCollectIn(this) {
            when(it.resultRecommend) {
                is ResultState.Success -> {
                    Toast.makeText(activity,"data fetched",Toast.LENGTH_LONG).show()
                    it.resultRecommend.data?.let {
                            data-> adapter.setItems(listOf(data))
                    }
                    binding.recycleRecommendation.adapter = adapter
                    binding.recycleRecommendation.layoutManager = LinearLayoutManager(activity)
                }
                else -> Unit
            }
        }

        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        binding.jakartaHolder.setOnClickListener {
            viewModel.getRecommend(rec = "Jakarta")
        }

        binding.bandungHolder.setOnClickListener {
            viewModel.getRecommend(rec = "Bandung")
        }

        binding.SemarangHolder.setOnClickListener {
            viewModel.getRecommend(rec = "Semarang")
        }

        binding.JogjaHolder.setOnClickListener {
            viewModel.getRecommend(rec = "Jogjakarta")
        }

        binding.surabayaHolder.setOnClickListener {
            viewModel.getRecommend(rec = "Surabaya")
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}