package com.dicoding.jelajava.Data.Response.Recommendation

data class Kota(
    val kota: List<String>
)