package com.dicoding.jelajava.Activity.Fragment.ProfileFragment

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.dicoding.jelajava.Activity.SettingActivity.SettingActivity
import com.dicoding.jelajava.Misc.Utility.Injection
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.launchAndCollectIn
import com.dicoding.jelajava.databinding.FragmentProfileBinding
import kotlinx.coroutines.launch


class ProfileFragment : Fragment() {
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private val viewModel by viewModels<ProfileViewModel>(factoryProducer = { Injection.profileViewModelFactory })

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {

        _binding = FragmentProfileBinding.inflate(inflater,container,false)

        binding.btnSetting.setOnClickListener {
            startActivity(Intent(activity,SettingActivity::class.java))
        }

        viewModel.profileState.launchAndCollectIn(this) {
            when(it.profileUser) {
                is ResultState.Success -> {
                    Toast.makeText(activity,"profile received",Toast.LENGTH_SHORT).show()
                    it.profileUser.data?.let {stories ->
                        binding.txtUsername.text = stories.username
                        binding.txtEmail.text = stories.email
                        Glide.with(this@ProfileFragment)
                            .load(stories.profilePicture)
                            .into(binding.profile)
                    }
                }

                else -> Unit
            }
        }
        viewModel.getProfile()

        return binding.root
    }

    override fun onResume() {
        super.onResume()
        lifecycleScope.launch {
            viewModel.getProfile()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

}