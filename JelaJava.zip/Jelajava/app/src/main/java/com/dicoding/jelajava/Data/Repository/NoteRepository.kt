package com.dicoding.jelajava.Data.Repository

import androidx.lifecycle.LiveData
import com.dicoding.jelajava.Data.NoteDatabase.Note
import com.dicoding.jelajava.Data.NoteDatabase.NoteDao

class NoteRepository(private val noteDao: NoteDao) {

    fun getAllNotes(): LiveData<List<Note>> {
        return noteDao.getAllNotes()
    }

    suspend fun addNote(note: Note) {
        noteDao.addNote(note)
    }

    suspend fun updateNote(note: Note) {
        noteDao.updateNote(note)
    }

    suspend fun deleteNote(note: Note) {
        noteDao.deleteNote(note)
    }
}