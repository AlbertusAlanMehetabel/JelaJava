package com.dicoding.jelajava.Data.Response.authResponse

data class UpdateUserResponse(
val success: Boolean,
val message: String
)

