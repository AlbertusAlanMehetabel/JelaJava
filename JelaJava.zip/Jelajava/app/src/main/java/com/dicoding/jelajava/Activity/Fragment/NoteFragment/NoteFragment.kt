package com.dicoding.jelajava.Activity.Fragment.NoteFragment



import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.SearchView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import com.dicoding.jelajava.Data.Adapter.NoteAdapter
import com.dicoding.jelajava.Data.NoteDatabase.Note
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.FragmentNoteBinding

class NoteFragment : Fragment() {

    private var _binding: FragmentNoteBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: NoteViewModel
    private lateinit var adapter: NoteAdapter

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentNoteBinding.inflate(inflater, container, false)
        val view = binding.root

        viewModel = ViewModelProvider(this)[NoteViewModel::class.java]
        adapter = NoteAdapter(requireContext())

        binding.recycleNote.layoutManager = StaggeredGridLayoutManager(2, LinearLayout.VERTICAL)
        binding.recycleNote.adapter = adapter

        binding.addNote.setOnClickListener {
            val addEditFragment = AddEditFragment.newInstance()
            parentFragmentManager.beginTransaction()
                .replace(R.id.frame_layout, addEditFragment)
                .addToBackStack(null)
                .commit()
        }

        adapter.setOnNoteClickListener { note ->
            openNoteDetail(note)
        }

        binding.searchNote.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                newText?.let {
                    val filteredList = viewModel.allNotes.value?.filter { note ->
                        note.title?.lowercase()?.contains(newText.lowercase()) == true ||
                                note.note?.lowercase()?.contains(newText.lowercase()) == true
                    }
                    adapter.submitList(filteredList)
                }
                return true
            }
        })

        observeNotes()

        return view
    }

    private fun openNoteDetail(note: Note) {
        val noteDetailFragment = AddEditFragment.newInstance(note)
        parentFragmentManager.beginTransaction()
            .replace(R.id.frame_layout, noteDetailFragment)
            .addToBackStack(null)
            .commit()
    }

    private fun observeNotes() {
        viewModel.allNotes.observe(viewLifecycleOwner) { notes ->
            adapter.submitList(notes)
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}