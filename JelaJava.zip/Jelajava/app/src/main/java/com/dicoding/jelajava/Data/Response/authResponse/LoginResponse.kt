package com.dicoding.jelajava.Data.Response.authResponse

data class LoginResponse(
    val message: String,
    val accessToken: String
)

