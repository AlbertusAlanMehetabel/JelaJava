package com.dicoding.jelajava.Data.Api


import com.dicoding.jelajava.Data.Response.authResponse.LoginResponse
import com.dicoding.jelajava.Data.Response.authResponse.LogoutResponse
import com.dicoding.jelajava.Data.Response.Recommendation.RecommendResponse
import com.dicoding.jelajava.Data.Response.authResponse.RegisterResponse
import retrofit2.http.Body
import retrofit2.http.POST

interface ApiService {
    @POST("auth/register")
    suspend fun register(
        @Body requestBody: HashMap<String, String>
    ): RegisterResponse

    @POST("auth/login")
    suspend fun login(
        @Body requestBody: HashMap<String, String>
    ): LoginResponse

    @POST("auth/logout")
    fun logout(): LogoutResponse

    @POST("api/ml/recommendation")
    fun recommend(
        @Body requestBody: HashMap<String, String>
    ): RecommendResponse

    @POST("api/ml/filter")
    fun filterRecommend(
        @Body requestBody: HashMap<String, String>
    ): RecommendResponse
}