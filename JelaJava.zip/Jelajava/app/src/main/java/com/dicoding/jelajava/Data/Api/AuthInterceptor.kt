package com.dicoding.jelajava.Data.Api

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.stringPreferencesKey
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import okhttp3.Interceptor
import okhttp3.Response

class AuthInterceptor(private val dataStore: DataStore<Preferences>): Interceptor {

    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()

        val token: String? = runBlocking {
            dataStore.data.first()[stringPreferencesKey("accessToken")]
        }

        return if (!token.isNullOrEmpty()) {
            val auth = original.newBuilder()
                .addHeader("Authorization","Bearer $token")
                .build()
            chain.proceed(auth)
        } else {
            chain.proceed(original)
        }
    }
}