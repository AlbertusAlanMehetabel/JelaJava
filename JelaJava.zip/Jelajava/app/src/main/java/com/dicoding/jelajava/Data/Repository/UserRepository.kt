package com.dicoding.jelajava.Data.Repository

import com.dicoding.jelajava.Data.Response.authResponse.UserEntity
import kotlinx.coroutines.flow.Flow

interface UserRepository {
    val userData: Flow<UserEntity>
    suspend fun saveUser(userEntity: UserEntity)
    suspend fun clearUser()
}