package com.dicoding.jelajava.Data.Response.NoteResponse

data class NoteResponse(
    val message: String
)
