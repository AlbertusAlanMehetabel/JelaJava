package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.ProfileRepository
import com.dicoding.jelajava.Data.Response.authResponse.ProfileEntity
import com.dicoding.jelajava.Misc.Utility.ResultState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class ProfileUseCase(private val profileRepository: ProfileRepository) {

    operator fun invoke(): Flow<ResultState<ProfileEntity>> = flow {
        emit(ResultState.Loading())
        profileRepository.getProfile().map {
            it.user.let {user->
                ProfileEntity(
                    email = user.email,
                    profilePicture = user.profilePicture,
                    username = user.name
                )
            }
        }.catch {
            emit(ResultState.Error(message = it.message.toString()))
        }.collect {
            emit(ResultState.Success(it))
        }
    }
}