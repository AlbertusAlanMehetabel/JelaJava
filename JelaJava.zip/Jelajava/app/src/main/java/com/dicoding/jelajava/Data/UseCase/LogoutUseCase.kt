package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.UserRepository

class LogoutUseCase(private val userPreferenceRepository: UserRepository) {
    suspend operator fun invoke() {
        userPreferenceRepository.clearUser()
    }
}