package com.dicoding.jelajava.Misc.Utility

import com.dicoding.jelajava.Data.Response.Recommendation.Kota

data class WelcomeViewState (
    val resultIsLoggedIn: ResultState<Boolean> = ResultState.Idle()
)

data class LoginViewState(
    val verifyUser: ResultState<String> = ResultState.Idle()
)

data class RegisterViewState(
    val resultRegisterUser: ResultState<String> = ResultState.Idle()
)

data class RecommendViewState(
    val resultRecommend: ResultState<List<Kota>> = ResultState.Idle()
)
