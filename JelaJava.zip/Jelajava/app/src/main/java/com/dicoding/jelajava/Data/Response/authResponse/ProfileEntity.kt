package com.dicoding.jelajava.Data.Response.authResponse

data class ProfileEntity(
    val profilePicture: String,
    val username: String,
    val email: String
)