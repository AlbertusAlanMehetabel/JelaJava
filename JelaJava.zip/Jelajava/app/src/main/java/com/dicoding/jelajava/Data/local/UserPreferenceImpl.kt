package com.dicoding.jelajava.Data.local

import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import com.dicoding.jelajava.Data.Repository.UserRepository
import com.dicoding.jelajava.Data.Response.authResponse.UserEntity
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map

class UserPreferenceImpl(private val dataStore: DataStore<Preferences>) : UserRepository {

    private object Keys {
        val token = stringPreferencesKey("accessToken")
    }

    private inline val Preferences.token
        get() = this[Keys.token] ?: ""

    override val dataUser: Flow<UserEntity> = dataStore.data.map {
        UserEntity(
            accessToken = it.token
        )
    }.distinctUntilChanged()

    override suspend fun saveUser(userEntity: UserEntity) {
        dataStore.edit { preferences ->
            preferences[Keys.token] = userEntity.accessToken
        }
    }

    override suspend fun clearUser() {
        dataStore.edit { preferences ->
            preferences.remove(Keys.token)
        }
    }

    override suspend fun getUserToken(): String {
        return dataStore.data.first()[Keys.token] ?: ""
    }
}