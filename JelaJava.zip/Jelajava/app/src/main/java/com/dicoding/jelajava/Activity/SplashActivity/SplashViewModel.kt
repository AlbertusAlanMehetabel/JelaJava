package com.dicoding.jelajava.Activity.SplashActivity

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.jelajava.Data.UseCase.GetUserUseCase
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.WelcomeViewState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class SplashViewModel(private val getUserUseCase: GetUserUseCase): ViewModel() {

    private val _splashState = MutableStateFlow(WelcomeViewState())
    val splashState = _splashState.asStateFlow()

    init {
        getIsLoggedIn()
    }

    private fun getIsLoggedIn() {
        viewModelScope.launch {
            getUserUseCase().collect { user ->
                delay(5000)
                _splashState.update {
                    it.copy(resultIsLoggedIn = ResultState.Success(user.accessToken!!.isNotEmpty()))
                }
            }
        }
    }
    class Factory(private val getUserCase: GetUserUseCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(SplashViewModel::class.java)) {
                return SplashViewModel(getUserCase) as T
            }
            error("unknown ViewModel class: $modelClass")
        }
    }
}