package com.dicoding.jelajava.Misc.Utility

import android.app.Application
import android.content.Context
import androidx.datastore.preferences.preferencesDataStore
import com.dicoding.jelajava.Activity.Fragment.HomeFragment.HomeViewModel
import com.dicoding.jelajava.Activity.Fragment.ProfileFragment.ProfileViewModel
import com.dicoding.jelajava.Activity.LoginActivity.LoginViewModel
import com.dicoding.jelajava.Activity.RegisterActivity.RegisterViewModel
import com.dicoding.jelajava.Activity.SettingActivity.SettingViewModel
import com.dicoding.jelajava.Activity.SplashActivity.SplashViewModel
import com.dicoding.jelajava.Data.Api.ApiConfig
import com.dicoding.jelajava.Data.Repository.Implementation.AuthRepositoryImpl
import com.dicoding.jelajava.Data.Repository.Implementation.ProfileRepositoryImpl
import com.dicoding.jelajava.Data.Repository.Implementation.RecommendRepositoryImpl
import com.dicoding.jelajava.Data.UseCase.GetRecommendUseCase
import com.dicoding.jelajava.Data.local.UserPreferenceImpl
import com.dicoding.jelajava.Data.UseCase.GetUserUseCase
import com.dicoding.jelajava.Data.UseCase.LoginUseCase
import com.dicoding.jelajava.Data.UseCase.LogoutUseCase
import com.dicoding.jelajava.Data.UseCase.ProfileUseCase
import com.dicoding.jelajava.Data.UseCase.RegisterUseCase

object Injection {
    private var application: Application? = null

    private inline val requireApplication
        get() = application ?: error("Missing call: initWith(application)")

    fun initWith(application: Application) {
        this.application = application
    }

    private val Context.dataStore by preferencesDataStore(name = "user_preferences")

    private val userPreferencesRepository by lazy {
        UserPreferenceImpl(requireApplication.dataStore)
    }

    private val authRepository by lazy {
        AuthRepositoryImpl(ApiConfig(requireApplication.dataStore).apiService)
    }

    private val dataRepository by lazy {
        RecommendRepositoryImpl(ApiConfig(requireApplication.dataStore).apiService)
    }

    private val profileRepository by lazy {
        ProfileRepositoryImpl(ApiConfig(requireApplication.dataStore).apiService)
    }

    private val loginUseCase get() = LoginUseCase(userPreferencesRepository, authRepository)
    private val registerUseCase get() = RegisterUseCase(authRepository)
    private val getUserCase get() = GetUserUseCase(userPreferencesRepository)
    private val logoutUseCase get() = LogoutUseCase(userPreferencesRepository)
    private val getRecommendUseCase get() = GetRecommendUseCase(dataRepository)
    private val profileUseCase get() = ProfileUseCase(profileRepository)


    val splashViewModelFactory
        get() = SplashViewModel.Factory(
            getUserCase = getUserCase
        )

    val loginViewModelFactory
        get() = LoginViewModel.Factory(
            loginUseCase = loginUseCase
        )

    val registerViewModelFactory
        get() = RegisterViewModel.Factory(
            registerUseCase = registerUseCase
        )

    val settingViewModelFactory
        get() = SettingViewModel.Factory(
            logoutUseCase = logoutUseCase
        )

    val homeViewModelFactory
        get() = HomeViewModel.Factory(
            getRecommendUseCase = getRecommendUseCase
        )

    val profileViewModelFactory
        get() = ProfileViewModel.Factory(
            profileUseCase = profileUseCase
        )
}
