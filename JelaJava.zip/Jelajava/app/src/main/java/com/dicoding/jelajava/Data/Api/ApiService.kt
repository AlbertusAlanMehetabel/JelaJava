package com.dicoding.jelajava.Data.Api



import com.dicoding.jelajava.Data.Response.authResponse.LoginResponse
import com.dicoding.jelajava.Data.Response.Recommendation.RecommendResponse
import com.dicoding.jelajava.Data.Response.authResponse.RegisterResponse
import com.dicoding.jelajava.Data.Response.authResponse.UserResponse
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

interface ApiService {
    @POST("auth/register")
    suspend fun register(
        @Body requestBody: HashMap<String, String>
    ): RegisterResponse

    @POST("auth/login")
    suspend fun login(
        @Body requestBody: HashMap<String, String>
    ): LoginResponse

    @POST("api/ml/filter")
    suspend fun recommend(
        @Body requestBody: HashMap<String, String>
    ): RecommendResponse

    @GET("/user/profile")
    suspend fun getProfile(): UserResponse
}