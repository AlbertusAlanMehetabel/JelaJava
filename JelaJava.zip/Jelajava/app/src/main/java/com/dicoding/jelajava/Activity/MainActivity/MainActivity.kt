package com.dicoding.jelajava.Activity.MainActivity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.dicoding.jelajava.Activity.Fragment.HomeFragment.HomeFragment
import com.dicoding.jelajava.Activity.Fragment.NoteFragment.NoteFragment
import com.dicoding.jelajava.Activity.Fragment.ProfileFragment.ProfileFragment
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        replaceFragment(HomeFragment())

        binding.botNav.setOnItemReselectedListener {
            when(it.itemId){

                R.id.home -> replaceFragment(HomeFragment())
                R.id.note -> replaceFragment(NoteFragment())
                R.id.profile -> replaceFragment(ProfileFragment())

                else -> {

                }
            }
        }
    }

    private fun replaceFragment(fragment: Fragment){

        val fragmentManager = supportFragmentManager
        val fragmentTransaction = fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.frame_layout,fragment)
        fragmentTransaction.commit()
    }
}