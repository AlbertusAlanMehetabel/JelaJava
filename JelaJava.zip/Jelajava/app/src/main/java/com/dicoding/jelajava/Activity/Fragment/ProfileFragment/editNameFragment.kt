package com.dicoding.jelajava.Activity.Fragment.ProfileFragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.FragmentEditNameBinding

class editNameFragment : Fragment() {

    private var _binding: FragmentEditNameBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentEditNameBinding.inflate(inflater, container, false)
        val view = binding.root

        // Retrieve and display the current username
        val currentUsername = getCurrentUsername()
        binding.etUsername.setText(currentUsername)

        binding.btnSave.setOnClickListener {
            val newUsername = binding.etUsername.text.toString().trim()

            // Replace the fragment with the ShowUsernameFragment to display the updated username
            requireActivity().supportFragmentManager.beginTransaction()
                .replace(R.id.frame_layout, ProfileFragment())
                .commit()
        }

        return view
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun getCurrentUsername(): String {
        // Replace this with your logic to fetch the current username from the API or local storage
        return "JohnDoe" // Example username
    }
}