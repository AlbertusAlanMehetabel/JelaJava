package com.dicoding.jelajava.Data.Repository

import com.dicoding.jelajava.Data.Response.authResponse.UserResponse
import kotlinx.coroutines.flow.Flow

interface ProfileRepository {
    fun getProfile(): Flow<UserResponse>
}