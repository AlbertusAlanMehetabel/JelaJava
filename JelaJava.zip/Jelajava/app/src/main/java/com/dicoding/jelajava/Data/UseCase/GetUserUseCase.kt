package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.UserRepository
import com.dicoding.jelajava.Data.Response.authResponse.UserEntity
import kotlinx.coroutines.flow.Flow

class GetUserUseCase(private val userPreferenceRepository: UserRepository) {
    operator fun invoke(): Flow<UserEntity> = userPreferenceRepository.userData
}