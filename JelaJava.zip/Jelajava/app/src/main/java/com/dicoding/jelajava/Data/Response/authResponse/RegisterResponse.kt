package com.dicoding.jelajava.Data.Response.authResponse

data class RegisterResponse(
    val error: Boolean,
    val message: String
)