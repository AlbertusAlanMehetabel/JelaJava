package com.dicoding.jelajava.Data.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.jelajava.Data.Response.Recommendation.Kota
import com.dicoding.jelajava.R


class KotaAdapter(private val kotaList: List<Kota>) :
    RecyclerView.Adapter<KotaAdapter.KotaViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): KotaViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_recommend_kota, parent, false)
        return KotaViewHolder(view)
    }

    override fun onBindViewHolder(holder: KotaViewHolder, position: Int) {
        val kota = kotaList[position]
        holder.bind(kota)
    }

    override fun getItemCount(): Int {
        return kotaList.size
    }

    inner class KotaViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val nameTextView: TextView = view.findViewById(R.id.tv_name)

        fun bind(kota: Kota) {
            nameTextView.text = kota.name
        }
    }
}