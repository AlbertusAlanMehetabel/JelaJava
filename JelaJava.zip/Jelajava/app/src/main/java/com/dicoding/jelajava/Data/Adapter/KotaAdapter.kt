package com.dicoding.jelajava.Data.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import com.bumptech.glide.Glide
import com.dicoding.jelajava.Data.Response.Recommendation.Kota
import com.dicoding.jelajava.Misc.Utility.DiffCallbackListener
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.ItemRecommendKotaBinding


class KotaAdapter : BaseAdapter<Kota, ItemRecommendKotaBinding>(diffCallbackListener) {

    companion object {
        val diffCallbackListener = object : DiffCallbackListener<Kota> {
            override fun areItemsTheSame(
                oldItem: Kota, newItem: Kota
            ) = oldItem.kota == newItem.kota
        }
    }

    override fun createViewHolder(inflater: LayoutInflater, container: ViewGroup) =
        ItemRecommendKotaBinding.inflate(inflater, container, false)

    override fun bind(binding: ItemRecommendKotaBinding, item: Kota, position: Int, count: Int) {
        binding.tvName.text = item.kota.toString()
        Glide.with(binding.root.context).load(R.drawable.placeholder).into(binding.ivItemPhoto)

    }
}
