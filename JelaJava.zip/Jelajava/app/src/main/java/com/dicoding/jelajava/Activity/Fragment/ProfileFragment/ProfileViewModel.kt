package com.dicoding.jelajava.Activity.Fragment.ProfileFragment

import androidx.lifecycle.ViewModel

class ProfileViewModel : ViewModel() {
    // TODO: Implement the ViewModel
}