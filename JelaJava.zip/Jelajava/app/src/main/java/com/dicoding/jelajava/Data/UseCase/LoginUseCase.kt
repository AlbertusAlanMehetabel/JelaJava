package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.AuthRepository
import com.dicoding.jelajava.Data.Repository.UserRepository
import com.dicoding.jelajava.Data.Response.authResponse.UserEntity
import com.dicoding.jelajava.Misc.Utility.ResultState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

class LoginUseCase (
    private val userPreferencesRepository: UserRepository,
    private val authenticationRepository: AuthRepository,
) {
    operator fun invoke(email: String, password: String): Flow<ResultState<String>> = flow {
        emit(ResultState.Loading())
        authenticationRepository.login(email, password).catch {
            emit(ResultState.Error(it.message.toString()))
        }.collect { result ->

                emit(ResultState.Success(result.message))
                result.accessToken.let{
                    userPreferencesRepository.saveUser(
                        UserEntity(
                            it
                        )
                    )
                }
        }
    }
}