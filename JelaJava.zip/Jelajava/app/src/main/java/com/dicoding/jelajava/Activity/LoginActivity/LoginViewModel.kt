package com.dicoding.jelajava.Activity.LoginActivity

import android.widget.Toast
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.jelajava.Data.UseCase.LoginUseCase
import com.dicoding.jelajava.Data.UseCase.LogoutUseCase
import com.dicoding.jelajava.Misc.Utility.LoginViewState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class LoginViewModel(private val loginUseCase: LoginUseCase): ViewModel() {

    private val _loginstate = MutableStateFlow(LoginViewState())
    val loginState = _loginstate.asStateFlow()

    fun login(email: String, password: String) {
        loginUseCase(email, password).onEach {result ->
            _loginstate.update {
                it.copy(verifyUser = result)
            }
        }.launchIn(viewModelScope)
    }


    class Factory(private val loginUseCase: LoginUseCase): ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(LoginViewModel::class.java)) {
                return LoginViewModel(loginUseCase) as T
            }
            error("Unknown ViewModel class: $modelClass")
        }
    }
}