package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.RecommendRepository
import com.dicoding.jelajava.Data.Response.Recommendation.Kota
import com.dicoding.jelajava.Misc.Utility.ResultState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map

class GetRecommendUseCase(private val recommendRepository: RecommendRepository) {
    operator fun invoke(rec: String): Flow<ResultState<List<Kota>>> = flow {
        emit(ResultState.Loading())
        recommendRepository.getRecommend(rec).map {
            it.listRecommendation.map { kota->
                Kota(
                    name = kota.recommendations
                )
            }
        }.catch {
            emit(ResultState.Error(message = it.message.toString()))
        }.collect {
            emit(ResultState.Success(it))
        }
    }
}