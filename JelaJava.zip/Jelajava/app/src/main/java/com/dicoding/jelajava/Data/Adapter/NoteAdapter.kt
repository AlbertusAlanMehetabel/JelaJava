package com.dicoding.jelajava.Data.Adapter

import android.content.Context
import android.content.res.TypedArray
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.dicoding.jelajava.Data.NoteDatabase.Note
import com.dicoding.jelajava.R

class NoteAdapter(
    private val context: Context,
) : ListAdapter<Note, NoteAdapter.NoteViewHolder>(NoteDiffCallback()) {

    interface OnItemClickListener {
        fun onItemClick(note: Note)
    }

    private var onItemClickListener: OnItemClickListener? = null

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): NoteViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_note, parent, false)
        return NoteViewHolder(view)
    }

    override fun onBindViewHolder(holder: NoteViewHolder, position: Int) {
        val currentNote = getItem(position)
        holder.bind(currentNote)

        holder.itemView.setOnClickListener {
            val note = getItem(holder.bindingAdapterPosition)
            onItemClickListener?.onItemClick(note)
        }
    }

    inner class NoteViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        private val noteLayout = view.findViewById<CardView>(R.id.card_note)
        private val titleTextView = view.findViewById<TextView>(R.id.txt_title)
        private val noteTextView = view.findViewById<TextView>(R.id.txt_note)
        private val dateTextView = view.findViewById<TextView>(R.id.txt_date)

        init {
            itemView.setOnClickListener {
                val position = bindingAdapterPosition
                if (position != RecyclerView.NO_POSITION) {
                    val note = getItem(position)
                    onItemClickListener?.onItemClick(note)
                }
            }
        }

        fun bind(note: Note) {
            titleTextView.text = note.title
            titleTextView.isSelected = true

            noteTextView.text = note.note
            dateTextView.text = note.date
            dateTextView.isSelected = true
        }
    }

    fun setOnNoteClickListener(listener: (note: Note) -> Unit) {
        onItemClickListener = object : OnItemClickListener {
            override fun onItemClick(note: Note) {
                listener(note)
            }
        }
    }

    private class NoteDiffCallback : DiffUtil.ItemCallback<Note>() {
        override fun areItemsTheSame(oldItem: Note, newItem: Note): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Note, newItem: Note): Boolean {
            return oldItem == newItem
        }
    }
}



