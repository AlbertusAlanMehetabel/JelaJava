package com.dicoding.jelajava.Activity.Fragment.HomeFragment

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.dicoding.jelajava.Data.UseCase.GetRecommendUseCase
import com.dicoding.jelajava.Misc.Utility.RecommendViewState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class HomeViewModel(private val getRecommendUseCase: GetRecommendUseCase): ViewModel() {
    private val _homeState = MutableStateFlow(RecommendViewState())
    private val homeState = _homeState.asStateFlow()

    fun getRecommend(rec: String) {
        viewModelScope.launch {
            getRecommendUseCase(rec).collect() { data->
                _homeState.update {
                    it.copy()
                }
            }
        }
    }

    class Factory(
        private val getRecommendUseCase: GetRecommendUseCase
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            if (modelClass.isAssignableFrom(HomeViewModel::class.java)) {
                return HomeViewModel(getRecommendUseCase) as T
            }
            error("Unknown ViewModel class: $modelClass")
        }
    }
}