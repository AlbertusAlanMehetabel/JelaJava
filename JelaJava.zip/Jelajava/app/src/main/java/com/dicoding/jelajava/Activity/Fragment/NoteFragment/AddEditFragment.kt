package com.dicoding.jelajava.Activity.Fragment.NoteFragment


import android.icu.text.SimpleDateFormat
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.lifecycle.ViewModelProvider
import com.dicoding.jelajava.Data.NoteDatabase.Note
import com.dicoding.jelajava.databinding.FragmentAddEditBinding
import java.util.Date
import java.util.Locale

class AddEditFragment : Fragment() {

    private var _binding: FragmentAddEditBinding? = null
    private val binding get() = _binding!!

    private lateinit var viewModel: NoteViewModel

    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return dateFormat.format(Date())
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentAddEditBinding.inflate(inflater, container, false)
        val view = binding.root

        viewModel = ViewModelProvider(requireActivity())[NoteViewModel::class.java]

        val note = arguments?.getParcelable<Note>(NOTE_EXTRA)

        if (note != null) {
            binding.txtNoteName.setText(note.title)
            binding.txtNoteInside.setText(note.note)
        }

        binding.imgUpdateNote.setOnClickListener {
            val title = binding.txtNoteName.text.toString().trim()
            val noteText = binding.txtNoteInside.text.toString().trim()

            if (title.isNotEmpty() || noteText.isNotEmpty()) {
                if (note != null) {
                    val updatedNote = note.copy(title = title, note = noteText)
                    viewModel.updateNote(updatedNote)
                } else {
                    val newNote = Note(
                        title = title,
                        note = noteText,
                        date = getCurrentDate()
                    )
                    viewModel.addNote(newNote)
                }
                closeFragment()
            } else {
                Toast.makeText(requireContext(), "Please enter a title or note", Toast.LENGTH_SHORT).show()
            }
        }

        binding.imgBack.setOnClickListener {
            closeFragment()
        }

        return view
    }

    private fun closeFragment() {
        requireActivity().supportFragmentManager.popBackStack()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        private const val NOTE_EXTRA = "note_extra"

        fun newInstance(note: Note? = null): AddEditFragment {
            val fragment = AddEditFragment()
            val args = Bundle().apply {
                putParcelable(NOTE_EXTRA, note)
            }
            fragment.arguments = args
            return fragment
        }
    }
}