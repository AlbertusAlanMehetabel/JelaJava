package com.dicoding.jelajava.Data.Response.authResponse

data class UserResponse(
    val username: String
)

data class UserUpdateResponse(
    val name: String
)
