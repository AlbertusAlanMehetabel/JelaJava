package com.dicoding.jelajava.Data.Repository

import com.dicoding.jelajava.Data.Response.authResponse.LoginResponse
import com.dicoding.jelajava.Data.Response.authResponse.RegisterResponse
import kotlinx.coroutines.flow.Flow

interface AuthRepository {
    fun register(email: String, password: String, name: String,confirmPassword: String): Flow<RegisterResponse>
    fun login(email: String, password: String): Flow<LoginResponse>
}