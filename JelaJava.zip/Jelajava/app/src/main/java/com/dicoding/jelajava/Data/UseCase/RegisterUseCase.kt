package com.dicoding.jelajava.Data.UseCase

import com.dicoding.jelajava.Data.Repository.AuthRepository
import com.dicoding.jelajava.Misc.Utility.ResultState
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow

class RegisterUseCase(
    private val authRepository: AuthRepository,
) {
    operator fun invoke(name: String, email: String, password: String, confirmPassword: String): Flow<ResultState<String>> =
        flow {
            emit(ResultState.Loading())
            authRepository.register(
                email, password, name, confirmPassword
            ).catch {
                emit(ResultState.Error(it.message.toString()))
            }.collect { result ->
                if (result.error) {
                    emit(ResultState.Error(result.message))
                } else {
                    emit(ResultState.Success(result.message))
                }
            }
        }
}