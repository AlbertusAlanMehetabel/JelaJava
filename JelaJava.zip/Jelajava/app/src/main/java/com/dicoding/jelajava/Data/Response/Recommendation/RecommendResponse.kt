package com.dicoding.jelajava.Data.Response.Recommendation

data class RecommendResponse(
    val message: String,
    val listRecommendation: RecommendList
)

data class RecommendList(
    val kota: List<String>
)