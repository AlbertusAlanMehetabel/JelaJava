package com.dicoding.jelajava.Misc.Utility

import android.app.Application

class App: Application() {
    override fun onCreate() {
        super.onCreate()
        Injection.initWith(this)
    }
}