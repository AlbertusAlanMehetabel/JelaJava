package com.dicoding.jelajava.Activity.RegisterActivity

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.activity.viewModels
import com.bumptech.glide.Glide
import com.dicoding.jelajava.Activity.LoginActivity.LoginActivity
import com.dicoding.jelajava.Misc.Utility.Injection
import com.dicoding.jelajava.Misc.Utility.ResultState
import com.dicoding.jelajava.Misc.Utility.launchAndCollectIn
import com.dicoding.jelajava.R
import com.dicoding.jelajava.databinding.ActivityRegisterBinding

class RegisterActivity : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterBinding
    private val viewModel by viewModels<RegisterViewModel>(factoryProducer = {Injection.registerViewModelFactory})

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)
        registerStart()

        viewModel.registerViewState.launchAndCollectIn(this) {
            when (it.resultRegisterUser) {
                is ResultState.Success<String> -> {
                    showLoading(false)
                    Toast.makeText(this@RegisterActivity,getString(R.string.register_success),Toast.LENGTH_SHORT).show()
                    startActivity(Intent(this@RegisterActivity,LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
                    finish()
                }
                is ResultState.Loading -> showLoading(true)
                is ResultState.Error ->  {
                    showLoading(false)
                    Toast.makeText(this@RegisterActivity, it.resultRegisterUser.message, Toast.LENGTH_SHORT).show()
                }
                else -> Unit
            }
        }

        Glide.with(this)
            .load(getString(R.string.logo_url))
            .into(binding.logo)

        binding.btnRegister.setOnClickListener {
                 if (binding.edtPasswordRegister.text.toString() != binding.edtConfirmPasswordRegister.text.toString()) {
                    Toast.makeText(this, R.string.password_dont_match, Toast.LENGTH_SHORT).show()
                } else if (binding.edtPasswordRegister.text.isNullOrEmpty() && binding.edtConfirmPasswordRegister.text.isNullOrEmpty()){
                     Toast.makeText(this, R.string.enter_password, Toast.LENGTH_SHORT).show()
                 }
                 else {
                     binding.btnRegister.setOnClickListener{

                         viewModel.registerUser(
                             name = binding.edtUsernameRegister.text.toString(),
                             email = binding.edtEmailRegister.text.toString(),
                             password = binding.edtPasswordRegister.text.toString(),
                             confirmPassword = binding.edtConfirmPasswordRegister.text.toString()
                         )
                     }
                }
        }

        binding.txtToLogin.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            finish()
        }

        binding.edtPasswordRegister.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence, start: Int, count: Int, after: Int) {
            }
            override fun onTextChanged(s: CharSequence, start: Int, before: Int, count: Int) {
                registerStart()
            }
            override fun afterTextChanged(s: Editable) {
            }
        })
    }

        private fun registerStart() {
        val validPassword = binding.edtPasswordRegister.text.toString()
        binding.btnRegister.isSaveEnabled = !TextUtils.isEmpty(validPassword) && validPassword.length >= 8
        }

    private fun showLoading(isLoading: Boolean) {
        binding.PBRegister.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}