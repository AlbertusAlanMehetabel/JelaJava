package com.dicoding.jelajava.Data.Repository

import com.dicoding.jelajava.Data.Response.Recommendation.RecommendResponse
import kotlinx.coroutines.flow.Flow

interface RecommendRepository {
    fun getRecommend(rec: String): Flow<RecommendResponse>
}
