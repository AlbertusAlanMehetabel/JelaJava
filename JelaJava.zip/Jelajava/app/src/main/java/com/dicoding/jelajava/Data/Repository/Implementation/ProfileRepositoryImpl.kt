package com.dicoding.jelajava.Data.Repository.Implementation

import com.dicoding.jelajava.Data.Api.ApiService
import com.dicoding.jelajava.Data.Repository.ProfileRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn

class ProfileRepositoryImpl(private val apiService: ApiService): ProfileRepository {
    override fun getProfile() = flow {
        emit(
            apiService.getProfile()
        )
    }.flowOn(Dispatchers.IO)
}