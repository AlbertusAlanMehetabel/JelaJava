package com.dicoding.jelajava.Data.Response.Recommendation

data class RecommendResponse(
    val message: String,
    val listRecommendation: List<data>
)

data class data(
    val recommendations:String,
    val total_recommendation: String,
    val user_Id: String
)